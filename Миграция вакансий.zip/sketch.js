let grid = [];
const row = 20;
const column = 20;
const atomdiametr = 40;
let jumpCounter = 0;
 
function setup() {
  createCanvas(800, 800);
  gridmaker();
      
  // Значения с ползунков и обнуление эксперимента
  select('#temperature').input(updateSimulation);
  select('#activationEnergy').input(updateSimulation);
  select('#simulationTime').input(updateSimulation);
  select('#resetBtn').mousePressed(resetCounter);
      
  updateSimulation();
}
    
function gridmaker() {
      // Генерация крист. решетки
  grid = [];
  for (let i = 0; i < row; i++) {
    grid[i] = [];
    for (let j = 0; j < column; j++) {
      // Шанс вакансий 5%
      grid[i][j] = {
        vacancy: random() < 0.05,
        x: j * atomdiametr + atomdiametr/2,
        y: i * atomdiametr + atomdiametr/2
      };
    }
  }
}
    
function exchangechance() {
  const T = select('#temperature').value();
  const E = select('#activationEnergy').value();
  const t = select('#simulationTime').value();
      
  // Условный расчет вероятности прыжка от заданных параметров
  const probability = Math.exp(T/E/20) * t;
      
  return Math.min(probability / 1e12, 0.1); 
}
    
function exchangeitself() {
  const probability = exchangechance();
      
  for (let i = 0; i < row; i++) {
    for (let j = 0; j < column; j++) {
      if (grid[i][j].vacancy) {
        // Перескок вакансии
        const directions = [
          {di: -1, dj: 0},  // вверх
          {di: 1, dj: 0},   // вниз
          {di: 0, dj: -1},  // влево
          {di: 0, dj: 1}    // вправо
        ];
            
        for (let dir of directions) {
          const ni = i + dir.di;
          const nj = j + dir.dj;
              
          // Проверка что будет попытка смены с атомом, а не вакансией, для избежания слияния вакансий и, следовательно уменьшения их числа
          if (ni >= 0 && ni < row && nj >= 0 && nj < column && 
              !grid[ni][nj].vacancy && random() < probability) {
                
            // Перескок вакансии
            grid[i][j].vacancy = false;
            grid[ni][nj].vacancy = true;
            jumpCounter++;
            break; 
          }
        }
      }
    }
  }
}
    
function draw() {
  background(255);
      
  // Рисуем сетку
  exchangeitself();
  drawGrid();
      
  // Обновляем отображения значений
  select('#tempValue').html(select('#temperature').value());
  select('#energyValue').html(select('#activationEnergy').value());
  select('#timeValue').html(select('#simulationTime').value());
  select('#counter').html('Перескоков вакансий: ' + jumpCounter);
}
    
function drawGrid() {
  for (let i = 0; i < row; i++) {
    for (let j = 0; j < column; j++) {
      const cell = grid[i][j];
          
      // Заполнение сетки атомами и вакансиями
      if (cell.vacancy) {
        fill(0); 
      } else {
        fill(255, 120, 0); 
      }
          
      ellipse(cell.x, cell.y, 30, 30);
    }
  }
}
    
function updateSimulation() {
}
    
function resetCounter() {
  jumpCounter = 0;
  gridmaker();
}